let startPauseButton = document.getElementById('start-pause-btn');
let resetButton = document.getElementById('reset-btn');
let lapButton = document.getElementById('lap-btn');
let timeDisplay = document.getElementById('time-display');
let lapsContainer = document.getElementById('laps');

let stopwatchInterval;
let elapsedTime = 0;
let isRunning = false;

// Start/Pause button functionality
startPauseButton.addEventListener('click', function() {
    if (!isRunning) {
        startStopwatch();
    } else {
        pauseStopwatch();
    }
});

// Reset button functionality
resetButton.addEventListener('click', resetStopwatch);

// Lap button functionality
lapButton.addEventListener('click', recordLap);

// Start the stopwatch
function startStopwatch() {
    startPauseButton.textContent = 'Pause';
    resetButton.disabled = false;
    lapButton.disabled = false;
    isRunning = true;

    let startTime = Date.now() - elapsedTime;
    stopwatchInterval = setInterval(function() {
        elapsedTime = Date.now() - startTime;
        updateTimeDisplay();
    }, 10);
}

// Pause the stopwatch
function pauseStopwatch() {
    clearInterval(stopwatchInterval);
    startPauseButton.textContent = 'Start';
    isRunning = false;
}

// Reset the stopwatch
function resetStopwatch() {
    clearInterval(stopwatchInterval);
    elapsedTime = 0;
    isRunning = false;
    startPauseButton.textContent = 'Start';
    resetButton.disabled = true;
    lapButton.disabled = true;
    updateTimeDisplay();
    lapsContainer.innerHTML = '';
}

// Update the time display
function updateTimeDisplay() {
    let milliseconds = Math.floor((elapsedTime % 1000) / 10);
    let seconds = Math.floor((elapsedTime / 1000) % 60);
    let minutes = Math.floor((elapsedTime / (1000 * 60)) % 60);
    let hours = Math.floor((elapsedTime / (1000 * 60 * 60)) % 24);

    milliseconds = milliseconds < 10 ? '0' + milliseconds : milliseconds;
    seconds = seconds < 10 ? '0' + seconds : seconds;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    hours = hours < 10 ? '0' + hours : hours;

    timeDisplay.textContent = `${hours}:${minutes}:${seconds}.${milliseconds}`;
}

// Record a lap time
function recordLap() {
    let lapTime = document.createElement('div');
    lapTime.classList.add('lap');
    lapTime.textContent = timeDisplay.textContent;
    lapsContainer.appendChild(lapTime);
}
